"""
# -----------------------------------------------------------------------------
# MLFlow sample code | Infrastructure and Architecture for AI (2024) 
# ------------------------------------------------------------------------------
"""
# %%
# -----------------------------------------------------------------------------
# Create the virtual environment: python3 -m venv venv 
# Next step: .\venv\Scripts\activate
# -----------------------------------------------------------------------------
# You will see in the terminal the name (venv)
# Next step: pip install -r requirements.txt
# This step is required to run / install all the reqs in the txt file
# -----------------------------------------------------------------------------
# Now you can start the MLFlow service in the terminal:
# mlflow ui
# Next step: Open the folowing adress using your browser.
# http://localhost:5000
# -----------------------------------------------------------------------------
# Alternativelly you can try the adresses below:
# http://0.0.0.0:5000 OR http://127.0.0.1:5000
# -----------------------------------------------------------------------------

# %%
#!pip install mlflow 
import pandas as pd
import mlflow
import statsmodels.api as sm
import json
import requests
import matplotlib.pyplot as plt

# %% dataset path and loading the dataset 
file_path = "./datasets/timedist.csv"
df_timedist = pd.read_csv(file_path)

# %% data loaded
df_timedist

# %% checking data and null values
df_timedist.info()

# %% colunms description
df_timedist.describe()

# %% model training - locally 
model_null_local = sm.OLS.from_formula(
    formula="time ~ distance", data=df_timedist
).fit()

# %% model summary 
model_null_local.summary()

# %% STARTING ML FLOW
# loading MLFlow and tracking the mlflow instance runing locally
mlflow.set_tracking_uri("http://localhost:5000")

# %% creating the experiment 
mlflow.set_experiment(experiment_name="Linear Regression - time distance3")

# %% MODEL INPUTS 
# model inputs defs - null model | Data collection to mlflow 
dataset = mlflow.data.from_pandas(df_timedist)
# formula used by the model 
formula = "time ~ 1"

# %% creating the first experiment in mlflow
with mlflow.start_run(run_name="Null Model"):
    mlflow.log_input(dataset, context="training")
    mlflow.log_param("Parameter Formula", formula)

    # MODELLING / Model training 
    model_null = sm.OLS.from_formula(formula=formula, data=df_timedist).fit()

    # outputs - model metrics
    mlflow.log_metric("F Value", model_null.fvalue)
    mlflow.log_metric("F p-value", model_null.f_pvalue)
    mlflow.log_metric("R Squared", model_null.rsquared)
    mlflow.log_metric("Model name", run_name)

    # collecting model artifacts | Picture with data vs fittedvalues
    fig, ax = plt.subplots()
    ax.scatter(df_timedist["time"], model_null.fittedvalues)
    ax.plot(ax.get_xlim(), ax.get_ylim(), ls="--", color="gray")

    # Picture as a experiment artifact
    mlflow.log_figure(
        fig, "observado_vs_fitted.png"
    )

    # summary in txt format
    model_null_summary_txt = model_null.summary().as_text()

    # add summary as a experiment artifact
    mlflow.log_text(
        model_null_summary_txt, "summary.txt"
    )

    # loading the model in the experiment
    mlflow.statsmodels.log_model(model_null, "null-model")

# %% loading the model from staging 
model_null_loaded = mlflow.statsmodels.load_model(
    "models:/time-distance/staging"
)

# %% checking R squared 
model_null_loaded.rsquared

# %% checking fitted values 
model_null_loaded.fittedvalues

# %% final model | metadata collection to mlflow
dataset = mlflow.data.from_pandas(df_timedist)
# formula to be utilized by the model 
formula = "time ~ distance"

# %% mlflow experiment creation
with mlflow.start_run(run_name="Final Model"):
    # inputs
    mlflow.log_input(dataset, context="training")
    # parameters collection 
    mlflow.log_param("Formula", formula)
    # modelling and model training
    final_model = sm.OLS.from_formula(
        formula=formula, data=df_timedist
    ).fit()

    # outputs | model metrics
    mlflow.log_metric("F Value", final_model.fvalue)
    mlflow.log_metric("F p-value", final_model.f_pvalue)
    mlflow.log_metric("R squared", final_model.rsquared)
    mlflow.log_metric("Model name", run_name)

    # model artifacts | Picture with fittevalues
    fig, ax = plt.subplots()
    ax.scatter(df_timedist["time"], final_model.fittedvalues)
    ax.plot(ax.get_xlim(), ax.get_ylim(), ls="--", color="gray")

    # picture as an artifact 
    mlflow.log_figure(
        fig, "observado_vs_fitted.png"
    )

    # getting summary as text
    final_model_summary_texto = final_model.summary().as_text()

    # adding summary as a artifact 
    mlflow.log_text(
        final_model_summary_texto, "summary.txt"
    )

    # loading the model in the experiment 
    mlflow.statsmodels.log_model(final_model, "final-model")

# %%

# Registrando uma nova versão do modelo tempo-dist
# Agora o modelo tempo-dist terá duas versões, o modelo nulo na versão 1 e o
# modelo final na versão 2.

# %%

# Após promover o modelo final para a fase de 'staging', o modelo nulo automa-
# ticamente o modelo anterior será e o novo modelo ficará registrado no estágio
# de 'staging' (adaptação)

# %% loading the model time-dist on stagging phase 
model_phase_staging = mlflow.statsmodels.load_model(
    "models:/time-distance/staging"
)

# %% checking R2
model_phase_staging.rsquared

# %% cheching fitted values
model_phase_staging.fittedvalues

# %% predic 
predict_novo_modelo_staging = modelo_fase_staging.predict(
    pd.DataFrame({"distance": [20]})
)
print(predict_novo_modelo_staging)

# %% checing predict result == Yhat= a + bx
print(5.8784+1.4189*20)
# %%
# MODELS LIFECYCLE
#
# %% model in PROD
model_in_prod = mlflow.statsmodels.load_model(
    "models:/time-distance/production"
)

# %% api utilization
dogs_api = requests.get(
    "https://dogapi.dog/api/v2/facts",
    headers={"Content-Type": "application/json"},
    verify=False,
)

# %% json format and api response 
dogs_api = dogs_api.json()
print(dogs_api["data"][0]["attributes"]["body"])

# %% PROD models with mlflow API
# go to the command line and activete a new venv
# -----------------------------------------------------------------------------
# cd <ORIGINAL FOLDER>
# Windows: .\venv\Scripts\activate
# Linux/macOS: source /venv/bin/activate
# You will see the prompt with "(venv)"
# -----------------------------------------------------------------------------
# add the environment variable, type in the terminal
# Windows: SET MLFLOW_TRACKING_URI=http://localhost:5000
# Linux/macOS: EXPORT MLFLOW_TRACKING_URI=http://localhost:5000
# -----------------------------------------------------------------------------
# model time-distance in prod can be acessed via port 5200
# mlflow models serve -m models:/time-distance/production -p 5200 --no-conda
# -----------------------------------------------------------------------------

# %% creating a dataframe to predict via PROD
df_new_data = pd.DataFrame({"distance": [20]})

# %% data transformation according to mlflow API reqs
data_transformed = json.dumps(
    {"dataframe_records": df_new_data.to_dict(orient="records")}
)

# %% api call via mlflow api and response 
response = requests.post(
    #url="http://localhost:5200/invocations",
    url="http://127.0.0.1:5200/invocations",
    data=data_transformed,
    headers={"Content-Type": "application/json"},
)

# %% checking the response - txt format 
response.text

# %% json format response 
predict = response.json()
print(predict["predictions"][0]["0"])
